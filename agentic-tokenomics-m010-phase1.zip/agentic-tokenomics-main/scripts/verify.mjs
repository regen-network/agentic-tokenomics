#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const repoRoot = process.cwd();

function requireFile(rel) {
  const p = path.join(repoRoot, rel);
  if (!fs.existsSync(p)) {
    console.error(`Missing required file: ${rel}`);
    process.exit(2);
  }
}

function run(cmd, args) {
  const res = spawnSync(cmd, args, { cwd: repoRoot, encoding: "utf8" });
  if (res.status !== 0) {
    console.error(res.stdout || "");
    console.error(res.stderr || "");
    process.exit(res.status ?? 3);
  }
}

function readJson(rel) {
  const p = path.join(repoRoot, rel);
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function requireSchemaVersion(obj, rel) {
  if (!obj || typeof obj !== "object") {
    console.error(`Invalid JSON object: ${rel}`);
    process.exit(4);
  }
  if (!("schema_version" in obj)) {
    console.error(`Missing schema_version: ${rel}`);
    process.exit(4);
  }
}

// Core files
requireFile("README.md");
requireFile("scripts/build-mechanism-index.mjs");
requireFile("scripts/run-m010-tests.mjs");

requireFile("mechanisms/m010-reputation-signal/README.md");
requireFile("mechanisms/m010-reputation-signal/SPEC.md");
requireFile("mechanisms/m010-reputation-signal/GLOSSARY.md");
requireFile("mechanisms/m010-reputation-signal/INVARIANTS.md");
requireFile("mechanisms/m010-reputation-signal/CHANGELOG.md");

requireFile("mechanisms/m010-reputation-signal/schemas/m010_kpi.schema.json");
requireFile("mechanisms/m010-reputation-signal/schemas/m010_event.schema.json");
requireFile("mechanisms/m010-reputation-signal/schemas/m010_signal.schema.json");
requireFile("mechanisms/m010-reputation-signal/schemas/SCHEMA_NOTES.md");

requireFile("mechanisms/m010-reputation-signal/datasets/schema.json");
requireFile("mechanisms/m010-reputation-signal/datasets/fixtures/v0_sample.json");

requireFile("mechanisms/m010-reputation-signal/reference-impl/index.mjs");

// 1) Mechanism index check
run("node", ["scripts/build-mechanism-index.mjs", "--check"]);

// 2) Basic schema sanity
const kpiSchema = readJson("mechanisms/m010-reputation-signal/schemas/m010_kpi.schema.json");
if (!Array.isArray(kpiSchema.required) || !kpiSchema.required.includes("mechanism_id") || !kpiSchema.required.includes("schema_version")) {
  console.error("KPI schema missing required fields (mechanism_id, schema_version).");
  process.exit(5);
}

const eventSchema = readJson("mechanisms/m010-reputation-signal/schemas/m010_event.schema.json");
if (!Array.isArray(eventSchema.required) || !eventSchema.required.includes("schema_version")) {
  console.error("Event schema missing required field (schema_version).");
  process.exit(5);
}

const ds = readJson("mechanisms/m010-reputation-signal/datasets/fixtures/v0_sample.json");
requireSchemaVersion(ds, "mechanisms/m010-reputation-signal/datasets/fixtures/v0_sample.json");
if (ds.mechanism_id !== "m010") {
  console.error("Fixture mechanism_id must be m010.");
  process.exit(6);
}

// 3) Golden-vector tests
run("node", ["scripts/run-m010-tests.mjs"]);

console.log("agentic-tokenomics verify: PASS");
