#!/usr/bin/env node
/**
 * Deterministic fixture generator for m010 (Phase 1).
 *
 * Usage:
 *   node scripts/gen-m010-fixture.mjs <seed> <outPath> [as_of_iso]
 */
import fs from "node:fs";
import path from "node:path";

const schemaVersion = "0.1.0";

function hashSeed(s) {
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h >>> 0;
}

function lcg(seed) {
  let x = seed >>> 0;
  return () => {
    // Numerical Recipes LCG
    x = (1664525 * x + 1013904223) >>> 0;
    return x;
  };
}

function isoZ(d) {
  return new Date(d).toISOString().replace(/\.\d{3}Z$/, "Z");
}

const repoRoot = process.cwd();
const seedStr = process.argv[2] ?? "v0_sample";
const outRel = process.argv[3] ?? path.join("mechanisms","m010-reputation-signal","datasets","fixtures","v0_sample.json");
const asOfStr = process.argv[4] ?? "2026-02-04T12:00:00Z";

const rng = lcg(hashSeed(seedStr));

const subjects = [
  ["CreditClass","C01-001","registry_quality"],
  ["Project","P-regen-042","delivery_risk"],
  ["Verifier","V-DeltaMRV","attestation_quality"],
  ["Methodology","METH-SoilCarbon-v3","method_rigor"],
  ["Address","regen1abcd...wxyz","operator_trust"],
  ["Project","P-regen-077","delivery_risk"],
];

function pick(arr) {
  return arr[rng() % arr.length];
}

function maybeLink(prefix, i, mod) {
  return (i % mod === 0) ? [] : [`${prefix}${i}`];
}

const asOf = new Date(asOfStr);
const events = [];
for (let i = 0; i < 12; i++) {
  const [subject_type, subject_id, category] = subjects[i % subjects.length];
  const hoursBack = 6*i + 3;
  const ts = new Date(asOf.getTime() - hoursBack * 60 * 60 * 1000);

  const endorsement_level = (i % 5) + 1;
  const signaler_id = `signaler_${(i % 4) + 1}`;

  const koi_links = maybeLink("koi://note/", i, 3);
  const ledger_refs = maybeLink("ledger://tx/", 1000 + i, 4);
  const web_links = maybeLink("https://example.invalid/ref/", i, 5);

  events.push({
    schema_version: schemaVersion,
    timestamp: isoZ(ts),
    subject_type,
    subject_id,
    category,
    endorsement_level,
    signaler_id,
    evidence: { koi_links, ledger_refs, web_links }
  });
}

const fixture = {
  schema_version: schemaVersion,
  mechanism_id: "m010",
  scope: "v0_advisory_replay",
  as_of: isoZ(asOf),
  generator_seed: seedStr,
  events
};

const outPath = path.isAbsolute(outRel) ? outRel : path.join(repoRoot, outRel);
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(fixture, null, 2) + "\n", "utf8");
console.log(`Wrote: ${outPath}`);
