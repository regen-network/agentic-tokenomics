#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { computeKpi, computeScore } from "../mechanisms/m010-reputation-signal/reference-impl/index.mjs";

const repoRoot = process.cwd();
const baseDir = path.join(repoRoot, "mechanisms", "m010-reputation-signal", "test_vectors");

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function deepEqual(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function runOne(n) {
  const vPath = path.join(baseDir, `vector_${n}.json`);
  const ePath = path.join(baseDir, `expected_${n}.json`);
  if (!fs.existsSync(vPath) || !fs.existsSync(ePath)) {
    console.error(`Missing vector/expected for ${n}`);
    process.exit(2);
  }

  const v = readJson(vPath);
  const expected = readJson(ePath);

  const kpi = computeKpi({
    as_of: v.as_of,
    events: v.events,
    sources_checked: v.sources_checked,
    scope: v.scope
  });

  const score = computeScore({
    as_of: v.as_of,
    events: v.events
  });

  const actual = { kpi, score };

  if (!deepEqual(actual, expected)) {
    console.error(`m010 vector ${n}: FAIL`);
    console.error("Expected:");
    console.error(JSON.stringify(expected, null, 2));
    console.error("Actual:");
    console.error(JSON.stringify(actual, null, 2));
    process.exit(3);
  }

  console.log(`m010 vector ${n}: PASS`);
}

runOne("01");
runOne("02");
console.log("m010 tests: PASS");
