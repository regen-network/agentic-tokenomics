# Changelog

## Unreleased
### Added
- Units 11–20: canonical schemas, mechanism index generator, consumers mapping, WG bulk pack, repo templates, and verification scripts.

### Notes
- This repo is primarily specification content; changes are intended to be deterministic and offline-friendly.
