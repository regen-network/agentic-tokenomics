---
name: Bug report
about: Report a problem with a mechanism/spec or validator
title: "[BUG] "
labels: bug
---

## What happened?
Describe the issue.

## Expected behavior
What did you expect?

## Repro steps
Provide file paths, commands, and/or minimal snippets.

## Impact
Who/what does this affect (downstream repos, WG review, etc.)?
