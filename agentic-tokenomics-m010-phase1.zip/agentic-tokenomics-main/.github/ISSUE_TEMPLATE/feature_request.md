---
name: Feature request
about: Request a new mechanism or spec improvement
title: "[FEATURE] "
labels: enhancement
---

## What do you want to add?
Describe the feature.

## Why?
Explain the value and how it compounds across the ecosystem.

## Acceptance criteria
Bullet list of what "done" means.
