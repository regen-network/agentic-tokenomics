## Summary
What does this change add/update?

## Checklist
- [ ] `node scripts/build-mechanism-index.mjs --check` passes
- [ ] Schemas updated (if applicable) and remain backward compatible (or versioned)
- [ ] Docs updated where needed (`docs/MECHANISM_CONSUMERS.md`, `WG_BULK_PACK.md`)
- [ ] No new network dependencies introduced

## Verification
Paste output of:
```bash
node scripts/verify.mjs
```
