# WG Phase 1 checklist — m010 Reputation Signal

This checklist is designed for a **5-minute** review.

## What to read (in order)
1) `mechanisms/m010-reputation-signal/README.md`
2) `mechanisms/m010-reputation-signal/SPEC.md`
3) `mechanisms/m010-reputation-signal/INVARIANTS.md`
4) `mechanisms/m010-reputation-signal/schemas/SCHEMA_NOTES.md`

## What to run (offline)
From repo root:

```bash
npm run verify
```

## What “PASS” means
- Mechanism index is consistent (no stale README listing)
- m010 schemas exist and include `schema_version`
- Reference implementation matches golden vectors (KPI + score)
- Deterministic fixture file exists and is schema-aligned

## Explicitly out of scope (Phase 1)
- Enforcement / gating / penalties
- Live MCP connectivity (Phase 1 remains runnable offline)
- Claiming truth about subjects beyond evidence pointers
