export { computeKpi } from "./m010_kpi.mjs";
export { computeScore } from "./m010_score.mjs";
