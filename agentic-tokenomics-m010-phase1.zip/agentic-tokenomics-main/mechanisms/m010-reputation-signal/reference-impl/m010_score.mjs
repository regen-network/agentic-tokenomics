/**
 * Optional m010 score (Phase 1)
 * Produces a normalized 0–1 score based on endorsement levels with exponential time decay.
 *
 * This is advisory. It is intended for ranking / triage, not enforcement.
 */
function clamp01(x) {
  if (x < 0) return 0;
  if (x > 1) return 1;
  return x;
}

export function computeScore({ as_of, events, half_life_days=30 }) {
  const asOf = new Date(as_of);
  const evs = Array.isArray(events) ? events : [];
  if (!evs.length) {
    return {
      schema_version: "0.1.0",
      mechanism_id: "m010",
      as_of,
      score_0_1: 0,
      method: "endorsement_level_with_time_decay",
      params: { half_life_days }
    };
  }

  const hlHours = half_life_days * 24;
  const ln2 = Math.log(2);

  let wSum = 0;
  let w = 0;

  for (const e of evs) {
    const lvl = Number(e?.endorsement_level ?? 0);
    if (!Number.isFinite(lvl) || lvl <= 0) continue;

    const ts = new Date(e?.timestamp);
    const ageHours = (asOf - ts) / (1000*60*60);
    if (!Number.isFinite(ageHours) || ageHours < 0) continue;

    // Normalize endorsement 1..5 to 0..1
    const x = clamp01((lvl - 1) / 4);
    const decay = Math.exp(-ln2 * (ageHours / hlHours));
    wSum += x * decay;
    w += decay;
  }

  const score = w ? clamp01(wSum / w) : 0;

  return {
    schema_version: "0.1.0",
    mechanism_id: "m010",
    as_of,
    score_0_1: Number(score.toFixed(4)),
    method: "endorsement_level_with_time_decay",
    params: { half_life_days }
  };
}
