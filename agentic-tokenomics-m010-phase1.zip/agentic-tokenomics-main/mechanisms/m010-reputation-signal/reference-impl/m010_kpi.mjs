/**
 * m010 KPI computation (Phase 1)
 * Deterministic, offline, no network.
 */
export function median(nums) {
  if (!nums.length) return null;
  const s = [...nums].sort((a,b)=>a-b);
  const mid = Math.floor(s.length/2);
  return s.length % 2 ? s[mid] : (s[mid-1] + s[mid]) / 2;
}

export function computeKpi({ as_of, events, sources_checked, scope="v0_advisory_replay" }) {
  const asOf = new Date(as_of);
  const evs = Array.isArray(events) ? events : [];
  const signals_emitted = evs.length;

  const subjects = new Set();
  let withEvidence = 0;
  const lat = [];

  for (const e of evs) {
    if (e && e.subject_type && e.subject_id) {
      subjects.add(`${e.subject_type}:${e.subject_id}`);
    }
    const evidence = e?.evidence ?? {};
    const koi = Array.isArray(evidence.koi_links) ? evidence.koi_links.length : 0;
    const led = Array.isArray(evidence.ledger_refs) ? evidence.ledger_refs.length : 0;
    const web = Array.isArray(evidence.web_links) ? evidence.web_links.length : 0;
    if ((koi + led + web) > 0) withEvidence += 1;

    const ts = new Date(e?.timestamp);
    const hours = (asOf - ts) / (1000*60*60);
    if (Number.isFinite(hours)) lat.push(hours);
  }

  const subjects_touched = subjects.size;
  const evidence_coverage_rate = signals_emitted ? Number((withEvidence / signals_emitted).toFixed(4)) : 0.0;
  const median_event_latency_hours = lat.length ? Number(median(lat).toFixed(2)) : null;

  const sc = sources_checked ?? {};

  return {
    schema_version: "0.1.0",
    mechanism_id: "m010",
    scope,
    as_of,
    signals_emitted,
    subjects_touched,
    evidence_coverage_rate,
    median_event_latency_hours,
    sources_checked: {
      koi: Boolean(sc.koi),
      ledger: Boolean(sc.ledger),
      web: Boolean(sc.web),
    }
  };
}
