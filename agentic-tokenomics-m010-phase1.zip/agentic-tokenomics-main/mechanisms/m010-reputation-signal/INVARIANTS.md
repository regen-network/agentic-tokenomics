# m010 Invariants (Phase 1)

These are **hard rules** for Phase 1 outputs. They exist to prevent KPI drift and fabricated outputs.

## 1) Advisory only
m010 outputs are **signals**, not enforcement. Phase 1 must not introduce gating, slashing, blocking, or on-chain actions.

## 2) No-fabrication
If `sources_checked` indicates **no sources were consulted**, then:
- `signals_emitted` MUST be `0`
- `subjects_touched` MUST be `0`
- `evidence_coverage_rate` MUST be `0.0`
- `median_event_latency_hours` MUST be `null`
- Any narrative text MUST clearly state it is unsupported / not verified

## 3) Determinism
Given identical inputs, outputs MUST match byte-for-byte (except for whitespace that is not semantically meaningful).  
This enables offline review and reproducible CI.

## 4) KPI definitions (Phase 1)
- `signals_emitted` = count of events provided to the computation
- `subjects_touched` = unique pairs of `(subject_type, subject_id)`
- `evidence_coverage_rate` = fraction of events that have **at least one** evidence pointer in **any** evidence array (`koi_links`, `ledger_refs`, `web_links`)
- `median_event_latency_hours` = median of `(as_of - timestamp)` in hours; `null` if there are zero valid timestamps

## 5) Schema compatibility
All JSON blocks intended for interchange MUST include:
- `schema_version` (string, semver-like)
- `mechanism_id` (`m010` where applicable)
