# m010 Reputation Signal (Phase 1)

m010 is an **advisory** mechanism for emitting reputation-relevant signals about subjects (projects, verifiers, methodologies, etc.) and summarizing them into a small KPI block.

## What this includes
- Spec: `SPEC.md`
- Glossary: `GLOSSARY.md`
- Invariants: `INVARIANTS.md`
- Schemas: `schemas/`
- Datasets: `datasets/`
- Reference implementation: `reference-impl/`
- Golden vectors: `test_vectors/`

## Verify (offline)
From repo root:

```bash
npm run verify
```

This runs:
- mechanism index check
- m010 schema sanity checks
- m010 golden-vector tests (KPI + score)

## Out of scope (Phase 1)
- Enforcement, gating, or on-chain actions
- Live MCP connectivity requirements (Phase 1 must remain runnable offline)
- Definitive “truth” about any subject (signals are advisory)
