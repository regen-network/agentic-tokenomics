# Schema notes (Phase 1)

## Versioning
All m010 interchange JSON includes `schema_version`. Phase 1 uses:

- `schema_version = "0.1.0"`

If fields change in a backward-incompatible way, bump `schema_version`.

## Required keys
- KPI block: `schema_version`, `mechanism_id`, `scope`, `as_of`, `signals_emitted`, `subjects_touched`, `evidence_coverage_rate`, `median_event_latency_hours`, `sources_checked`
- Dataset event: `schema_version`, `timestamp`, `subject_type`, `subject_id`, `category`, `endorsement_level`, `signaler_id`, `evidence`
- Signal item: `schema_version`, `timestamp`, `subject_type`, `subject_id`, `category`, `evidence` (endorsement/signaler are optional)

## Allowed ranges
- `endorsement_level`: 1–5
- KPI counters: integers >= 0
- `evidence_coverage_rate`: 0.0–1.0
