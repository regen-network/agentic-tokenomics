# m010 Schemas (Phase 1)

These JSON Schemas define the **canonical shapes** for Phase 1 interchange artifacts.

- `m010_kpi.schema.json` — KPI summary block
- `m010_event.schema.json` — dataset event item
- `m010_signal.schema.json` — signal item (for digests / lists)

See `SCHEMA_NOTES.md` for versioning and ranges.
