# m010 Datasets (Phase 1)

Datasets are **deterministic** JSON fixtures used for offline review and tests.

## Fixtures
- `fixtures/v0_sample.json` is generated from a seed and should remain stable.

Regenerate (from repo root):

```bash
node scripts/gen-m010-fixture.mjs v0_sample mechanisms/m010-reputation-signal/datasets/fixtures/v0_sample.json 2026-02-04T12:00:00Z
```

If regeneration changes the file, that is a breaking change and must be reviewed.
