# m010 Glossary

This glossary defines terms used in **m010 Reputation Signal** artifacts.

## Key terms

**Mechanism ID**: `m010`. A stable identifier for this mechanism package.

**Scope**: A short string describing the run context (e.g., `v0_advisory_replay`, `v0_advisory_stub`, `v0_advisory_mcp`).

**Signal**: A single advisory event about a subject (e.g., a project or verifier) that includes an optional endorsement level and evidence pointers.

**KPI**: A small set of numeric summary fields computed from a set of signals/events.

**Subject**: The target of a signal (identified by `subject_type` and `subject_id`).

**Evidence**: Pointers that justify why a signal exists. In Phase 1, evidence is represented only as references/links:
- `koi_links[]`
- `ledger_refs[]`
- `web_links[]`

**sources_checked**: A truthy/falsey record indicating what sources were actually consulted for a run. Used to enforce the **no-fabrication** invariant.

**No-fabrication**: If `sources_checked` indicates no sources were consulted, KPIs must be zero/null and any claims must be explicitly marked as unsupported.
