# m010 — Reputation Signal (SPEC)

## Header
- **ID:** m010
- **Name:** Reputation Signal
- **Status:** Phase 1 (advisory-only)
- **Schema version:** 0.1.0
- **Last updated:** 2026-02-06

## Purpose
Provide a **shared, queryable advisory signal** about subjects (projects, verifiers, methodologies, etc.) based on explicit endorsements and evidence pointers, plus a small KPI summary block.

## Scope (Phase 1)
Phase 1 defines:
- Data shapes (schemas)
- KPI + score computation (reference implementation)
- Deterministic fixtures and golden vectors
- Offline verification (`npm run verify`)

Phase 1 does **not** define enforcement, gating, or on-chain actions.

## Non-goals (Phase 1)
- Slashing, blocking, curation enforcement, or policy changes
- “Truth” claims beyond evidence pointers
- Requiring live MCP/network access to evaluate correctness

## Core objects
### Signal event (advisory)
A signal event includes:
- subject: (`subject_type`, `subject_id`)
- category: string (e.g., `delivery_risk`, `attestation_quality`)
- optional endorsement: `endorsement_level` (1–5)
- evidence pointers: arrays of links/refs (`koi_links`, `ledger_refs`, `web_links`)
- timestamp: ISO-8601 datetime

### KPI block (summary)
Given a set of events at `as_of`, compute:
- `signals_emitted`: count of events
- `subjects_touched`: unique subjects
- `evidence_coverage_rate`: fraction of events with ≥1 evidence pointer
- `median_event_latency_hours`: median age of events in hours (null if none)

### Optional score (0–1)
A normalized 0–1 score derived from `endorsement_level` with exponential time decay (advisory ranking only).

## Safety: no-fabrication
If no sources were consulted (`sources_checked` indicates all false), KPIs must be zero/null and outputs must be explicitly marked as unsupported. See `INVARIANTS.md`.
