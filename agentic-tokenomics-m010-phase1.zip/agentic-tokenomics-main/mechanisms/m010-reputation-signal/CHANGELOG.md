# m010 Changelog

All notable changes to **m010 Reputation Signal** will be documented here.

## 0.1.0
- Phase 1 packaging: spec + glossary + invariants
- Canonical JSON schemas for KPI, event, and signal
- Deterministic datasets and fixture generator
- Reference implementation (KPI + score) with golden test vectors
- Offline verification command (`npm run verify`)
